package com.finephoto.editor

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import com.finephoto.editor.engine.ImageProcessor
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

private val fineDarkColorScheme = darkColorScheme(
    primary = Color(0xFF7C5CFF),
    onPrimary = Color.White,
    secondary = Color(0xFFB7A8FF),
    background = Color(0xFF090A0F),
    surface = Color(0xFF11131A),
    surfaceVariant = Color(0xFF1A1D26),
    onBackground = Color(0xFFF5F5F7),
    onSurface = Color(0xFFF5F5F7)
)

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = fineDarkColorScheme,
                typography = Typography(
                    bodyLarge = MaterialTheme.typography.bodyLarge.copy(
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Default
                    )
                )
            ) {
                FinePhotoEditorApp()
            }
        }
    }
}

private fun decodeEditorBitmap(
    context: android.content.Context,
    uri: android.net.Uri,
    maxDimension: Int
): Bitmap? {
    val resolver = context.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

    var sample = 1
    while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) {
        sample *= 2
    }

    val options = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return resolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, options)
    }
}

@Composable
fun FinePhotoEditorApp() {
    val viewModel: MainViewModel = viewModel()
    val state by viewModel.uiState.collectAsState()
    var showBrandIntro by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(1550)
        showBrandIntro = false
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = fineDarkColorScheme.background
    ) {
        Box(Modifier.fillMaxSize()) {
            when (state.currentScreen) {
                Screen.Home -> HomeScreen(viewModel, state)
                Screen.Editor -> EditorScreen(viewModel, state)
            }

            if (showBrandIntro) {
                AnimatedBrandIntro()
            }
        }
    }
}

@Composable
private fun AnimatedBrandIntro() {
    var started by remember { mutableStateOf(false) }
    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (started) 1f else 0.72f,
        animationSpec = androidx.compose.animation.core.spring(
            dampingRatio = 0.72f,
            stiffness = 420f
        ),
        label = "logoScale"
    )
    val alpha by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (started) 1f else 0f,
        animationSpec = androidx.compose.animation.core.tween(420),
        label = "logoAlpha"
    )

    LaunchedEffect(Unit) {
        started = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF21134D),
                        Color(0xFF0B0B12),
                        Color(0xFF050509)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                this.alpha = alpha
                scaleX = scale
                scaleY = scale
            }
        ) {
            Box(
                modifier = Modifier
                    .size(126.dp)
                    .clip(RoundedCornerShape(34.dp))
                    .background(Color(0xFF090A0F))
                    .padding(9.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(com.finephoto.editor.R.drawable.fine_logo),
                    contentDescription = "Fine Photo Editor",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(Modifier.height(24.dp))
            Text(
                text = "Fine Photo Editor",
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(Modifier.height(7.dp))
            Text(
                text = "EDIT  •  ENHANCE  •  CREATE",
                fontSize = 10.sp,
                letterSpacing = 2.sp,
                color = Color(0xFFB7A8FF),
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

data class UIState(
    val currentScreen: Screen = Screen.Home,
    val selectedImage: Bitmap? = null,
    val processedImage: Bitmap? = null,
    val adjustmentState: ImageProcessor.AdjustmentState = ImageProcessor.AdjustmentState(),
    val isProcessing: Boolean = false,
    val selectedCategory: String = "Basic",
    val selectedPreset: String? = null,
    val history: List<ImageProcessor.AdjustmentState> = emptyList(),
    val historyIndex: Int = -1,
    val zoomScale: Float = 1f,
    val panOffset: Offset = Offset.Zero,
    val exportQuality: Int = 90,
    val showBeforeAfter: Boolean = false
)

enum class Screen { Home, Editor }

class MainViewModel : androidx.lifecycle.ViewModel() {
    private val _uiState = MutableStateFlow(UIState())
    val uiState: StateFlow<UIState> = _uiState.asStateFlow()

    private val imageProcessor = ImageProcessor()
    private var originalBitmap: Bitmap? = null
    private var previewBitmap: Bitmap? = null
    private var processingJob: Job? = null
    private var historyJob: Job? = null
    private var renderVersion = 0L

    fun loadImage(bitmap: Bitmap) {
        processingJob?.cancel()
        historyJob?.cancel()
        originalBitmap?.takeIf { it !== bitmap && !it.isRecycled }?.recycle()
        previewBitmap?.takeIf { !it.isRecycled }?.recycle()

        originalBitmap = bitmap
        previewBitmap = imageProcessor.createPreviewBitmap(bitmap, 1080)
        val clean = ImageProcessor.AdjustmentState()
        _uiState.value = UIState(
            currentScreen = Screen.Editor,
            selectedImage = previewBitmap,
            processedImage = previewBitmap,
            adjustmentState = clean,
            history = listOf(imageProcessor.snapshot(clean)),
            historyIndex = 0
        )
        processImage(immediate = true)
    }

    fun updateAdjustment(block: ImageProcessor.AdjustmentState.() -> Unit) {
        val current = _uiState.value.adjustmentState
        val next = imageProcessor.snapshot(current).apply(block)
        _uiState.update { it.copy(adjustmentState = next, selectedPreset = null) }

        // Don't create a history entry for every finger movement. Commit once the user pauses.
        historyJob?.cancel()
        historyJob = viewModelScope.launch {
            delay(350)
            val committed = imageProcessor.snapshot(_uiState.value.adjustmentState)
            _uiState.update { state ->
                val base = state.history.take(state.historyIndex + 1)
                val newHistory = if (base.lastOrNull() == committed) base else base + committed
                state.copy(history = newHistory, historyIndex = newHistory.lastIndex)
            }
        }
        processImage()
    }

    fun undo() {
        historyJob?.cancel()
        val history = _uiState.value.history
        val index = _uiState.value.historyIndex
        if (index > 0) {
            val next = imageProcessor.snapshot(history[index - 1])
            _uiState.update { it.copy(historyIndex = index - 1, adjustmentState = next, selectedPreset = null) }
            processImage(immediate = true)
        }
    }

    fun redo() {
        historyJob?.cancel()
        val history = _uiState.value.history
        val index = _uiState.value.historyIndex
        if (index < history.lastIndex) {
            val next = imageProcessor.snapshot(history[index + 1])
            _uiState.update { it.copy(historyIndex = index + 1, adjustmentState = next, selectedPreset = null) }
            processImage(immediate = true)
        }
    }

    fun reset() {
        historyJob?.cancel()
        val clean = ImageProcessor.AdjustmentState()
        _uiState.update {
            it.copy(
                adjustmentState = clean,
                history = listOf(imageProcessor.snapshot(clean)),
                historyIndex = 0,
                selectedPreset = null
            )
        }
        processImage(immediate = true)
    }

    suspend fun autoEnhance() {
        val bitmap = originalBitmap ?: return
        val autoState = imageProcessor.autoEnhance(bitmap)
        _uiState.update { it.copy(adjustmentState = autoState, selectedPreset = null) }
        processImage(immediate = true)
    }

    fun applyPreset(preset: Preset) {
        historyJob?.cancel()
        val newState = preset.applyTo(ImageProcessor.AdjustmentState())
        val snapshot = imageProcessor.snapshot(newState)
        _uiState.update {
            val base = it.history.take(it.historyIndex + 1)
            val h = base + snapshot
            it.copy(adjustmentState = snapshot, selectedPreset = preset.name, history = h, historyIndex = h.lastIndex)
        }
        processImage(immediate = true)
    }

    private fun processImage(immediate: Boolean = false) {
        processingJob?.cancel()
        val version = ++renderVersion
        processingJob = viewModelScope.launch(Dispatchers.Default) {
            if (!immediate) delay(55)
            val bitmap = previewBitmap ?: return@launch
            val state = imageProcessor.snapshot(_uiState.value.adjustmentState)
            _uiState.update { it.copy(isProcessing = true) }
            val processed = imageProcessor.processImage(bitmap, state, previewMode = true)
            if (version != renderVersion || !isActive) {
                if (!processed.isRecycled) processed.recycle()
                return@launch
            }
            _uiState.update { it.copy(processedImage = processed, isProcessing = false) }
        }
    }

    suspend fun renderFullResolution(): Bitmap? {
        val bitmap = originalBitmap ?: return null
        val state = imageProcessor.snapshot(_uiState.value.adjustmentState)
        return imageProcessor.processImage(bitmap, state, previewMode = false)
    }

    override fun onCleared() {
        processingJob?.cancel()
        historyJob?.cancel()
        previewBitmap?.takeIf { !it.isRecycled }?.recycle()
        originalBitmap?.takeIf { !it.isRecycled }?.recycle()
        super.onCleared()
    }

    fun applyAiMode(mode: String) {
        historyJob?.cancel()
        val next = imageProcessor.snapshot(_uiState.value.adjustmentState)
        when (mode) {
            "Auto" -> {
                val source = originalBitmap
                if (source != null) {
                    viewModelScope.launch {
                        val ai = imageProcessor.autoEnhance(source)
                        _uiState.update { it.copy(adjustmentState = ai, selectedPreset = "AI Auto") }
                        processImage(immediate = true)
                    }
                    return
                }
            }
            "Portrait" -> { next.exposure += 0.08f; next.contrast += 0.08f; next.shadows += 0.12f; next.highlights -= 0.10f; next.temperature += 0.08f; next.saturation += 0.04f; next.clarity = -0.08f; next.sharpen += 0.12f }
            "Cinematic" -> { next.contrast += 0.18f; next.highlights -= 0.22f; next.shadows += 0.10f; next.temperature += 0.05f; next.tint -= 0.04f; next.vibrance += 0.16f; next.fade += 0.06f; next.vignette += 0.12f }
            "Night Fix" -> { next.exposure += 0.26f; next.shadows += 0.30f; next.highlights -= 0.25f; next.contrast += 0.06f; next.vibrance += 0.10f; next.sharpen += 0.12f }
            "Sky Pop" -> { next.exposure += 0.04f; next.contrast += 0.12f; next.vibrance += 0.22f; next.saturation += 0.10f; next.dehaze += 0.16f; next.highlights -= 0.14f }
            "Golden Hour" -> { next.exposure += 0.10f; next.temperature += 0.28f; next.tint += 0.03f; next.vibrance += 0.16f; next.highlights -= 0.10f; next.shadows += 0.10f }
            "Clean Pro" -> { next.exposure += 0.04f; next.contrast += 0.08f; next.highlights -= 0.08f; next.shadows += 0.08f; next.saturation -= 0.02f; next.vibrance += 0.10f; next.sharpen += 0.14f; next.clarity += 0.06f }
            "Film Look" -> { next.contrast += 0.10f; next.saturation -= 0.05f; next.vibrance += 0.08f; next.temperature += 0.04f; next.fade += 0.16f; next.grain += 0.10f; next.vignette += 0.10f }
        }
        val snapshot = imageProcessor.snapshot(next)
        _uiState.update { state ->
            val base = state.history.take(state.historyIndex + 1)
            val h = base + snapshot
            state.copy(adjustmentState = snapshot, selectedPreset = "AI $mode", history = h, historyIndex = h.lastIndex)
        }
        processImage(immediate = true)
    }

    fun goHome() {
        _uiState.update { it.copy(currentScreen = Screen.Home) }
    }

    fun updateZoomScale(scale: Float) {
        _uiState.update { it.copy(zoomScale = scale.coerceIn(0.5f, 3f)) }
    }

    fun updatePanOffset(offset: Offset) {
        _uiState.update { it.copy(panOffset = offset) }
    }

    fun toggleBeforeAfter() {
        _uiState.update { it.copy(showBeforeAfter = !it.showBeforeAfter) }
    }
}

data class Preset(
    val name: String,
    val category: String,
    val icon: String,
    val applyTo: (ImageProcessor.AdjustmentState) -> ImageProcessor.AdjustmentState
)

object Presets {
    private val names = listOf(
        "Cinematic", "Golden Hour", "Moody", "Dreamy", "Clean", "Urban", "Street", "Travel", "Portrait", "Film", "Vintage", "Retro",
        "Noir", "Pastel", "Vivid", "Matte", "Editorial", "Luxury", "Minimal", "Warm", "Cool", "Teal", "Orange", "Faded",
        "Sunset", "Ocean", "Forest", "Desert", "Neon", "Cyber", "Classic", "Natural", "Soft", "Bold", "Drama", "Night",
        "Dawn", "Dusk", "Coffee", "Autumn", "Winter", "Summer", "Spring", "Golden", "Silver", "Rose", "Lavender", "Emerald",
        "Sapphire", "Ruby", "Amber", "Arctic", "Tropical", "Coastal", "Mountain", "City", "Studio", "Wedding", "Fashion", "Food",
        "Cafe", "Architecture", "Luxury Film", "Analog", "35mm", "Polaroid", "Kodak", "Fuji", "Ilford", "Chrome", "Classic Film", "Cinema",
        "Indie", "Music", "Concert", "Sports", "Fitness", "Creator", "Social", "Reel", "TikTok", "Story", "Minimal Dark", "High Key",
        "Low Key", "Bright", "Airy", "Deep", "Rich", "Crisp", "Soft Matte", "Cream", "Peach", "Mint", "Sky", "Berry",
        "Chocolate", "Honey", "Copper", "Steel", "Platinum", "Midnight", "Moonlight", "Starlight", "Electric", "Aurora", "Haze", "Mist"
    )
    private val icons = listOf("✦", "◈", "✧", "◆", "●", "◉", "◇", "✺")
    val categories = listOf("Cinematic", "Portrait", "Travel", "Film", "Vintage", "Moody", "Social", "Creative")

    val all: List<Preset> = (0 until 120).map { i ->
        val base = names[i % names.size]
        val variant = i / names.size + 1
        val name = if (variant == 1) base else "$base $variant"
        val category = categories[i % categories.size]
        Preset(name, category, icons[i % icons.size]) { original ->
            val s = original.copy()
            val wave = i % 12
            s.exposure = ((wave - 5) / 12f).coerceIn(-0.45f, 0.45f)
            s.contrast = (((i * 7) % 15 - 7) / 15f).coerceIn(-0.5f, 0.5f)
            s.saturation = (((i * 11) % 17 - 8) / 17f).coerceIn(-0.5f, 0.5f)
            s.vibrance = (((i * 5) % 13 - 6) / 13f).coerceIn(-0.45f, 0.45f)
            s.temperature = (((i * 3) % 13 - 6) / 13f).coerceIn(-0.45f, 0.45f)
            s.tint = (((i * 9) % 11 - 5) / 11f).coerceIn(-0.4f, 0.4f)
            s.highlights = -((i % 7) / 18f)
            s.shadows = (i % 6) / 15f
            s.clarity = ((i % 9) / 18f)
            s.sharpen = ((i % 8) / 20f)
            s.grain = if (i % 4 == 0) (i % 7) / 18f else 0f
            s.vignette = if (i % 5 == 0) (i % 8) / 14f else 0f
            s.fade = if (i % 6 == 0) (i % 6) / 16f else 0f
            s
        }
    }
}

data class FilterPreset(
    val name: String,
    val category: String,
    val icon: String,
    val applyTo: (ImageProcessor.AdjustmentState) -> ImageProcessor.AdjustmentState
)

object Filters {
    private val styles = listOf(
        "Luma", "Chrome", "Velvet", "Silk", "Cobalt", "Amber", "Rose", "Mint", "Ice", "Fire", "Film",
        "Fade", "Glow", "Matte", "Punch", "Soft", "Deep", "Clean", "Dream", "Noir", "Retro", "Analog",
        "VHS", "Polaroid", "35mm", "Grain", "Dust", "Bloom", "Neon", "Cyber", "Cinema", "Drama", "Editorial",
        "Portrait", "Skin", "Golden", "Sunset", "Dusk", "Night", "Ocean", "Forest", "Desert", "Arctic", "Tropical",
        "Urban", "Street", "Cafe", "Luxury", "Fashion", "Classic", "Natural", "Vivid", "Pastel", "Cream", "Peach",
        "Berry", "Honey", "Copper", "Steel", "Silver", "Platinum", "Emerald", "Sapphire", "Ruby", "Lavender",
        "Sky", "Moon", "Star", "Aurora", "Haze", "Mist", "Cloud", "Rain", "Summer", "Winter", "Spring", "Autumn",
        "High Key", "Low Key", "Bright", "Dark", "Rich", "Crisp", "Soft Focus", "Hard Light", "Muted", "Faded", "Warm",
        "Cool", "Teal", "Orange", "Split Tone", "Monochrome", "Sepia", "Duotone", "Bleach", "Magazine", "Creator", "Social",
        "Reel", "Story", "Concert", "Sports", "Food", "Architecture", "Wedding", "Travel", "Pro", "Signature"
    )
    private val groups = listOf("Film", "Color", "Mood", "Portrait", "Travel", "Vintage", "Creative", "Social", "B&W", "Cinema")
    private val icons = listOf("◉", "◌", "✦", "◆", "◇", "✧", "●", "◈")

    val all: List<FilterPreset> = (0 until 120).map { i ->
        val base = styles[i % styles.size]
        val variant = i / styles.size + 1
        val name = if (variant == 1) base else "$base $variant"
        FilterPreset(name, groups[i % groups.size], icons[i % icons.size]) { original ->
            val s = original.copy()
            val k = i % 20
            s.saturation = ((k - 9) / 18f).coerceIn(-0.5f, 0.5f)
            s.contrast = (((k * 3) % 13 - 6) / 14f).coerceIn(-0.45f, 0.45f)
            s.temperature = (((k * 5) % 15 - 7) / 16f).coerceIn(-0.45f, 0.45f)
            s.vibrance = (((k * 7) % 13 - 6) / 16f).coerceIn(-0.4f, 0.4f)
            s.highlights = -((k % 6) / 16f)
            s.shadows = (k % 7) / 18f
            s.fade = if (i % 3 == 0) (k % 6) / 16f else 0f
            s.grain = if (i % 4 == 0) (k % 7) / 18f else 0f
            s.vignette = if (i % 5 == 0) (k % 6) / 14f else 0f
            s
        }
    }
}

data class QuickTool(
    val name: String,
    val icon: String,
    val applyTo: (ImageProcessor.AdjustmentState) -> ImageProcessor.AdjustmentState
)

object QuickTools {
    private val names = listOf(
        "Auto", "Exposure", "Contrast", "Highlights", "Shadows", "Whites", "Blacks", "Warmth", "Coolness", "Tint",
        "Saturation", "Vibrance", "Clarity", "Texture", "Dehaze", "Sharpen", "Grain", "Vignette", "Fade", "Punch",
        "Soft Light", "Deep Shadows", "Bright Whites", "Matte", "Film Wash", "Color Pop", "Skin Soft", "Sky Boost", "Detail",
        "Portrait Light", "Golden Light", "Blue Hour", "Sunset Glow", "Night Boost", "Street Pop", "Travel Pop", "Food Pop", "Green Boost", "Blue Boost",
        "Red Boost", "Orange Boost", "Yellow Boost", "Purple Boost", "Cyan Boost", "Vintage Wash", "Cinema Wash", "Noir", "Dream", "Glow",
        "Bloom", "Haze", "Fog", "Dust", "Analog", "Retro", "Polaroid", "VHS", "Chrome", "Sepia", "B&W", "High Key", "Low Key",
        "Clean Skin", "Soft Skin", "Face Light", "Eye Pop", "Hair Detail", "Background Fade", "Subject Pop", "Depth", "Micro Contrast", "Macro Detail",
        "Landscape", "Architecture", "Portrait Pro", "Studio Pro", "Wedding", "Fashion", "Creator", "Social", "Reel", "Story", "Thumbnail", "Profile",
        "Cafe", "Nightlife", "Concert", "Sports", "Beach", "Mountain", "Forest", "Desert", "City", "Neon City", "Luxury", "Minimal",
        "Warm Film", "Cool Film", "Faded Film", "Rich Film", "Cinematic", "Editorial", "Magazine", "Classic", "Modern", "Signature"
    )
    val all: List<QuickTool> = (0 until 120).map { i ->
        QuickTool(names[i % names.size] + if (i >= names.size) " ${i / names.size + 1}" else "", "✦") { original ->
            val s = original.copy()
            when (i % 12) {
                0 -> { s.exposure = 0.12f; s.contrast = 0.12f; s.vibrance = 0.16f }
                1 -> s.exposure = (s.exposure + 0.18f).coerceIn(-2f, 2f)
                2 -> s.contrast = (s.contrast + 0.16f).coerceIn(-1f, 1f)
                3 -> s.highlights = (s.highlights - 0.16f).coerceIn(-1f, 1f)
                4 -> s.shadows = (s.shadows + 0.18f).coerceIn(-1f, 1f)
                5 -> s.whites = (s.whites + 0.15f).coerceIn(-1f, 1f)
                6 -> s.blacks = (s.blacks - 0.15f).coerceIn(-1f, 1f)
                7 -> s.temperature = (s.temperature + 0.15f).coerceIn(-1f, 1f)
                8 -> s.temperature = (s.temperature - 0.15f).coerceIn(-1f, 1f)
                9 -> s.saturation = (s.saturation + 0.16f).coerceIn(-1f, 1f)
                10 -> s.vibrance = (s.vibrance + 0.18f).coerceIn(-1f, 1f)
                11 -> { s.clarity = (s.clarity + 0.14f).coerceIn(-1f, 1f); s.sharpen = (s.sharpen + 0.1f).coerceIn(0f, 1f) }
            }
            s
        }
    }
}


@Composable
fun HomeScreen(viewModel: MainViewModel, state: UIState) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        result.data?.data?.let { uri ->
            scope.launch { decodeEditorBitmap(context, uri, 4096)?.let(viewModel::loadImage) }
        }
    }

    val pulse = rememberInfiniteTransition(label = "heroPulse")
    val glow by pulse.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )

    Box(Modifier.fillMaxSize().background(Color(0xFF05060B))) {
        Box(
            Modifier.fillMaxWidth().height(430.dp).graphicsLayer { alpha = 0.9f * glow }
                .background(Brush.radialGradient(listOf(Color(0xFF39206E), Color(0xFF11152A), Color.Transparent)))
        )
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 18.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFF10121B)).padding(5.dp),
                    contentAlignment = Alignment.Center
                ) { Image(painterResource(R.drawable.fine_logo), null, Modifier.fillMaxSize()) }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("FINE", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 2.5.sp)
                    Text("AI PHOTO EDITOR", color = Color(0xFF898CA0), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
                }
                Surface(shape = RoundedCornerShape(50), color = Color(0x221C8BFF), border = BorderStroke(1.dp, Color(0x446C63FF))) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFBDA7FF), modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(5.dp)); Text("AI", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(30.dp))
            Text("YOUR PHOTO,", color = Color(0xFF8E91A2), fontSize = 14.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.4.sp)
            Text("reimagined by AI.", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, lineHeight = 38.sp)
            Spacer(Modifier.height(9.dp))
            Text("One tap to enhance. Full control when you want it.", color = Color(0xFFA1A4B3), fontSize = 13.sp)

            Spacer(Modifier.height(22.dp))
            Card(
                Modifier.fillMaxWidth().height(196.dp).clickable { galleryLauncher.launch(Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)) },
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                border = BorderStroke(1.dp, Color(0x445C52A8))
            ) {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF1D1538), Color(0xFF10131F), Color(0xFF0C0D13))))) {
                    Box(Modifier.align(Alignment.TopEnd).size(170.dp).graphicsLayer { alpha = 0.75f }.background(Brush.radialGradient(listOf(Color(0xFF6C3BFF), Color.Transparent))))
                    Column(Modifier.align(Alignment.Center).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(58.dp).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Color(0xFF8D5CFF), Color(0xFF4A5CFF)))), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AddPhotoAlternate, null, tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.height(13.dp))
                        Text("Start a new edit", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("Gallery  •  Camera  •  AI Enhance", color = Color(0xFFA8AABB), fontSize = 11.sp)
                    }
                }
            }

            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeActionCard("AI MAGIC", "One-tap", Icons.Default.AutoFixHigh, Color(0xFF9B7CFF), Modifier.weight(1f))
                HomeActionCard("STYLES", "120+", Icons.Default.AutoAwesome, Color(0xFFFF5CA8), Modifier.weight(1f))
                HomeActionCard("FILTERS", "120+", Icons.Default.FilterVintage, Color(0xFF39C6FF), Modifier.weight(1f))
            }

            Spacer(Modifier.height(28.dp))
            SectionHeader("AI STUDIO", "SMART TOOLS")
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(end = 10.dp)) {
                items(listOf(
                    Triple("AI Auto", "Fix light + color", Icons.Default.AutoFixHigh),
                    Triple("Portrait AI", "Skin + light", Icons.Default.Face),
                    Triple("Night Fix", "Recover shadows", Icons.Default.Nightlight),
                    Triple("Sky Pop", "Depth + color", Icons.Default.Cloud),
                    Triple("Cinematic", "Movie-grade", Icons.Default.Movie)
                )) { item ->
                    AIHomeCard(item.first, item.second, item.third) { viewModel.applyAiMode(item.first) }
                }
            }

            Spacer(Modifier.height(28.dp))
            SectionHeader("DISCOVER", "TRENDING LOOKS")
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(end = 10.dp)) {
                items(Presets.all.take(12)) { preset -> DiscoverPresetCard(preset) { galleryLauncher.launch(Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)) } }
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
private fun HomeActionCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, modifier: Modifier) {
    Card(modifier.height(88.dp).then(modifier), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF10121A)), border = BorderStroke(1.dp, Color(0x221F2330))) {
        Column(Modifier.fillMaxSize().padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(20.dp))
            Column { Text(label, color = Color(0xFF767A8D), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp); Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun SectionHeader(title: String, action: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
        Spacer(Modifier.weight(1f)); Text(action, color = Color(0xFF6F7282), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

@Composable
private fun AIHomeCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(Modifier.width(164.dp).height(126.dp).clickable(onClick = onClick), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF11131D)), border = BorderStroke(1.dp, Color(0x332D2A4D))) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF1D1732), Color(0xFF10121A))))) {
            Icon(icon, null, tint = Color(0xFFB996FF), modifier = Modifier.padding(16.dp).size(24.dp))
            Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(subtitle, color = Color(0xFF85899B), fontSize = 10.sp) }
        }
    }
}

@Composable
private fun DiscoverPresetCard(preset: Preset, onClick: () -> Unit) {
    Card(Modifier.width(128.dp).height(154.dp).clickable(onClick = onClick), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF11131A))) {
        Box(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF46306D), Color(0xFF182B4A), Color(0xFF0D1016)))))
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD07080D)))))
            Column(Modifier.align(Alignment.BottomStart).padding(13.dp)) {
                Text(preset.icon, color = Color.White, fontSize = 16.sp)
                Text(preset.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(preset.category, color = Color(0xFF9B9EAE), fontSize = 9.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(viewModel: MainViewModel, state: UIState) {
    var selectedTool by remember { mutableStateOf("AI") }
    var showSaveDialog by remember { mutableStateOf(false) }
    var exportQuality by remember { mutableStateOf(94) }
    var showOriginal by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val image = if (showOriginal) state.selectedImage else state.processedImage

    val tools = listOf(
        "AI" to Icons.Default.AutoAwesome,
        "Looks" to Icons.Default.AutoAwesome,
        "Filters" to Icons.Default.FilterVintage,
        "Adjust" to Icons.Default.Tune,
        "Color" to Icons.Default.ColorLens,
        "Effects" to Icons.Default.WbTwilight,
        "Tools" to Icons.Default.Crop
    )

    Box(Modifier.fillMaxSize().background(Color(0xFF030408))) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = viewModel::goHome) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("FINE AI", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp)
                    Text(if (state.isProcessing) "AI rendering…" else "Studio", color = Color(0xFF6F7280), fontSize = 9.sp)
                }
                Surface(shape = RoundedCornerShape(50), color = Color(0x221E1838), border = BorderStroke(1.dp, Color(0x443E2B6B))) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFC3A7FF), modifier = Modifier.size(13.dp)); Spacer(Modifier.width(4.dp)); Text("AI", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                IconButton(onClick = { showOriginal = !showOriginal }) { Icon(Icons.Default.Compare, "Before after", tint = if (showOriginal) Color(0xFFB38CFF) else Color.White) }
                IconButton(onClick = { viewModel.undo() }, enabled = state.historyIndex > 0) { Icon(Icons.Default.Undo, "Undo", tint = if (state.historyIndex > 0) Color.White else Color(0xFF3D404A)) }
                IconButton(onClick = { showSaveDialog = true }) { Icon(Icons.Default.IosShare, "Export", tint = Color(0xFFB38CFF)) }
            }

            Box(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 10.dp), contentAlignment = Alignment.Center) {
                if (image != null) {
                    Image(bitmap = image.asImageBitmap(), contentDescription = "Edited photo", modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(22.dp)), contentScale = ContentScale.Fit)
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Photo, null, tint = Color(0xFF363947), modifier = Modifier.size(54.dp)); Text("Choose a photo", color = Color(0xFF666A79), fontSize = 13.sp) }
                }
                if (state.isProcessing) Surface(Modifier.align(Alignment.TopCenter).padding(top = 10.dp), shape = RoundedCornerShape(50), color = Color(0xDD0B0D14), border = BorderStroke(1.dp, Color(0x334C3B78))) {
                    Row(Modifier.padding(horizontal = 13.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(13.dp), strokeWidth = 2.dp, color = Color(0xFFB38CFF)); Spacer(Modifier.width(7.dp)); Text("AI processing", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                }
                if (image != null && !state.isProcessing) {
                    Surface(Modifier.align(Alignment.BottomEnd).padding(12.dp), shape = RoundedCornerShape(50), color = Color(0xAA080910), border = BorderStroke(1.dp, Color(0x334B4F62))) {
                        Text(if (showOriginal) "ORIGINAL" else "AI PREVIEW", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp, modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp))
                    }
                }
            }

            Surface(color = Color(0xFF080A10), shadowElevation = 20.dp) {
                Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    LazyRow(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), contentPadding = PaddingValues(horizontal = 3.dp)) {
                        items(tools) { (name, icon) ->
                            val active = selectedTool == name
                            Surface(onClick = { selectedTool = name }, shape = RoundedCornerShape(15.dp), color = if (active) Color(0xFF1B1530) else Color.Transparent, border = if (active) BorderStroke(1.dp, Color(0x554F3A86)) else null) {
                                Column(Modifier.width(64.dp).padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(icon, null, tint = if (active) Color(0xFFC2A7FF) else Color(0xFF767A8A), modifier = Modifier.size(20.dp)); Spacer(Modifier.height(4.dp)); Text(name, color = if (active) Color.White else Color(0xFF858998), fontSize = 9.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium)
                                }
                            }
                        }
                    }
                    AnimatedContent(targetState = selectedTool, label = "editorPanel") { tool ->
                        Column(Modifier.fillMaxWidth().heightIn(min = 150.dp, max = 300.dp).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 10.dp)) {
                            when (tool) {
                                "AI" -> AIPanel(viewModel)
                                "Looks" -> LooksPanel(viewModel)
                                "Filters" -> FiltersPanel(viewModel)
                                "Adjust" -> AdjustPanel(viewModel, state)
                                "Color" -> ColorPanel(viewModel, state)
                                "Effects" -> EffectsPanel(viewModel, state)
                                "Tools" -> ToolsPanel(viewModel, state)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSaveDialog) {
        AlertDialog(onDismissRequest = { showSaveDialog = false }, containerColor = Color(0xFF12141C), title = { Text("Export master", color = Color.White, fontWeight = FontWeight.Bold) }, text = { Column { Text("JPEG quality", color = Color(0xFF9093A2), fontSize = 12.sp); Slider(value = exportQuality.toFloat(), onValueChange = { exportQuality = it.toInt() }, valueRange = 60f..100f); Text("$exportQuality%", color = Color.White, fontSize = 12.sp, modifier = Modifier.align(Alignment.End)) } }, confirmButton = { TextButton(onClick = { showSaveDialog = false; scope.launch { Toast.makeText(context, "Rendering full resolution…", Toast.LENGTH_SHORT).show(); viewModel.renderFullResolution()?.let { bitmap -> saveImageToGallery(context, bitmap, exportQuality); if (!bitmap.isRecycled) bitmap.recycle(); Toast.makeText(context, "Saved to Gallery", Toast.LENGTH_SHORT).show() } } }) { Text("Export", color = Color(0xFFC0A6FF), fontWeight = FontWeight.Bold) } }, dismissButton = { TextButton(onClick = { showSaveDialog = false }) { Text("Cancel", color = Color(0xFF7F8290)) } })
    }
}

@Composable private fun AIPanel(viewModel: MainViewModel) {
    Text("AI STUDIO", color = Color(0xFF777B8C), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp)
    Spacer(Modifier.height(8.dp))
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), border = BorderStroke(1.dp, Color(0x554F3A86))) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF251A45), Color(0xFF11131D)))).padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(Color(0xFF9B6BFF), Color(0xFF4E63FF)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoFixHigh, null, tint = Color.White) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("AI Auto Enhance", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text("Analyze light, tone and color", color = Color(0xFF8D91A3), fontSize = 10.sp) }; Button(onClick = { viewModel.applyAiMode("Auto") }, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF)), contentPadding = PaddingValues(horizontal = 13.dp, vertical = 8.dp)) { Text("MAGIC", fontSize = 10.sp, fontWeight = FontWeight.Bold) } }
        }
    }
    Spacer(Modifier.height(12.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) { items(listOf("Portrait", "Cinematic", "Night Fix", "Sky Pop", "Golden Hour", "Clean Pro", "Film Look")) { mode -> AIChip(mode) { viewModel.applyAiMode(mode) } } }
}

@Composable private fun AIChip(text: String, onClick: () -> Unit) { Surface(onClick = onClick, shape = RoundedCornerShape(14.dp), color = Color(0xFF11131C), border = BorderStroke(1.dp, Color(0x332F3444))) { Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFA988FF), modifier = Modifier.size(14.dp)); Spacer(Modifier.width(6.dp)); Text(text, color = Color(0xFFD8D9E1), fontSize = 10.sp, fontWeight = FontWeight.SemiBold) } } }

@Composable private fun LooksPanel(viewModel: MainViewModel) { Text("AI LOOKS", color = Color(0xFF777B8C), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp); Spacer(Modifier.height(8.dp)); LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) { items(Presets.all.take(30)) { p -> LookCard(p) { viewModel.applyPreset(p) } } } }

@Composable private fun LookCard(p: Preset, onClick: () -> Unit) { Card(Modifier.width(100.dp).height(118.dp).clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF12141B))) { Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF43315E), Color(0xFF17223B), Color(0xFF0C0E14))))) { Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE08090D))))); Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) { Text(p.icon, color = Color.White, fontSize = 14.sp); Text(p.name, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1); Text(p.category, color = Color(0xFF858999), fontSize = 8.sp) } } } }

@Composable private fun FiltersPanel(viewModel: MainViewModel) { Text("FILTER LAB", color = Color(0xFF777B8C), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp); Spacer(Modifier.height(8.dp)); LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) { items(Filters.all.take(40)) { f -> FilterCard(f) { viewModel.updateAdjustment { f.applyTo(this) } } } } }

@Composable private fun FilterCard(f: FilterPreset, onClick: () -> Unit) { Card(Modifier.width(92.dp).height(112.dp).clickable(onClick = onClick), shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF11131A))) { Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF174E65), Color(0xFF2C1B4D), Color(0xFF0A0D13))))) { Column(Modifier.align(Alignment.BottomStart).padding(9.dp)) { Text(f.icon, color = Color.White, fontSize = 13.sp); Text(f.name, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1); Text(f.category, color = Color(0xFF7F8391), fontSize = 8.sp) } } } }

@Composable private fun AdjustPanel(viewModel: MainViewModel, state: UIState) { Text("LIGHT", color = Color(0xFF777B8C), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp); AdjustmentSlider("Exposure", state.adjustmentState.exposure, -2f..2f) { viewModel.updateAdjustment { exposure = it } }; AdjustmentSlider("Contrast", state.adjustmentState.contrast, -1f..1f) { viewModel.updateAdjustment { contrast = it } }; AdjustmentSlider("Highlights", state.adjustmentState.highlights, -1f..1f) { viewModel.updateAdjustment { highlights = it } }; AdjustmentSlider("Shadows", state.adjustmentState.shadows, -1f..1f) { viewModel.updateAdjustment { shadows = it } }; AdjustmentSlider("Whites", state.adjustmentState.whites, -1f..1f) { viewModel.updateAdjustment { whites = it } }; AdjustmentSlider("Blacks", state.adjustmentState.blacks, -1f..1f) { viewModel.updateAdjustment { blacks = it } } }

@Composable private fun ColorPanel(viewModel: MainViewModel, state: UIState) { Text("COLOR", color = Color(0xFF777B8C), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp); AdjustmentSlider("Temperature", state.adjustmentState.temperature, -1f..1f) { viewModel.updateAdjustment { temperature = it } }; AdjustmentSlider("Tint", state.adjustmentState.tint, -1f..1f) { viewModel.updateAdjustment { tint = it } }; AdjustmentSlider("Saturation", state.adjustmentState.saturation, -1f..1f) { viewModel.updateAdjustment { saturation = it } }; AdjustmentSlider("Vibrance", state.adjustmentState.vibrance, -1f..1f) { viewModel.updateAdjustment { vibrance = it } }; Text("8-channel HSL engine", color = Color(0xFF676B7A), fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp)) }

@Composable private fun EffectsPanel(viewModel: MainViewModel, state: UIState) { Text("FINISH", color = Color(0xFF777B8C), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp); AdjustmentSlider("Clarity", state.adjustmentState.clarity, -1f..1f) { viewModel.updateAdjustment { clarity = it } }; AdjustmentSlider("Sharpen", state.adjustmentState.sharpen, 0f..1f) { viewModel.updateAdjustment { sharpen = it } }; AdjustmentSlider("Grain", state.adjustmentState.grain, 0f..1f) { viewModel.updateAdjustment { grain = it } }; AdjustmentSlider("Vignette", state.adjustmentState.vignette, 0f..1f) { viewModel.updateAdjustment { vignette = it } }; AdjustmentSlider("Fade", state.adjustmentState.fade, 0f..1f) { viewModel.updateAdjustment { fade = it } } }

@Composable private fun ToolsPanel(viewModel: MainViewModel, state: UIState) { Text("AI TOOLS", color = Color(0xFF777B8C), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp); Spacer(Modifier.height(8.dp)); LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) { items(QuickTools.all) { tool -> Surface(onClick = { viewModel.updateAdjustment { tool.applyTo(this) } }, shape = RoundedCornerShape(15.dp), color = Color(0xFF11131A), border = BorderStroke(1.dp, Color(0x22282D3B))) { Column(Modifier.width(70.dp).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(Color(0xFF1B1E28)), contentAlignment = Alignment.Center) { Text(tool.icon, color = Color(0xFFB89BFF), fontSize = 17.sp) }; Spacer(Modifier.height(5.dp)); Text(tool.name, color = Color(0xFFB8BAC4), fontSize = 8.sp, maxLines = 1) } } } }; Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = { viewModel.updateAdjustment { rotation = (rotation + 90) % 360 } }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.RotateRight, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Rotate", fontSize = 10.sp) }; OutlinedButton(onClick = { viewModel.updateAdjustment { flipHorizontal = !flipHorizontal } }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Flip, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Flip", fontSize = 10.sp) } } }

@Composable
fun AdjustmentSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = Color.White, fontSize = 13.sp)
            Text(String.format("%.1f", value), color = Color.Gray, fontSize = 12.sp)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF007AFF),
                activeTrackColor = Color(0xFF007AFF),
                inactiveTrackColor = Color(0xFF2A2A2A)
            ),
            modifier = Modifier.height(28.dp)
        )
    }
}

suspend fun saveImageToGallery(context: android.content.Context, bitmap: Bitmap, quality: Int) {
    withContext(Dispatchers.IO) {
        val filename = "FinePhoto_${System.currentTimeMillis()}.jpg"
        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FinePhotoEditor")
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
            }
        }
    }
}

