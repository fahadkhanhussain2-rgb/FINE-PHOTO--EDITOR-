# FINE PHOTO EDITOR - Professional Photo Editor

## Features
- Import from Gallery & Camera
- Full image editing (Exposure, Contrast, Highlights, Shadows, etc.)
- 8-Channel HSL adjustments
- 16 Professional Presets
- AI Auto-Enhance
- Undo/Redo/Reset
- Pinch-to-zoom & Pan
- Before/After comparison
- Export to Gallery

## GitHub Actions build
The included workflow installs Gradle 8.2 and Android SDK 34, then builds the debug APK automatically.

Artifact: `FinePhotoEditor-Debug`
