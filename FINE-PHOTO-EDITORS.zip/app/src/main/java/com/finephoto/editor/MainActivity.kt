package com.finephoto.editor

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import com.finephoto.editor.engine.ImageProcessor
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

private val fineDarkColorScheme = darkColorScheme(
    primary = Color(0xFF7C5CFF),
    onPrimary = Color.White,
    secondary = Color(0xFFB7A8FF),
    background = Color(0xFF090A0F),
    surface = Color(0xFF11131A),
    surfaceVariant = Color(0xFF1A1D26),
    onBackground = Color(0xFFF5F5F7),
    onSurface = Color(0xFFF5F5F7)
)

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = fineDarkColorScheme,
                typography = Typography(
                    bodyLarge = MaterialTheme.typography.bodyLarge.copy(
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Default
                    )
                )
            ) {
                FinePhotoEditorApp()
            }
        }
    }
}

private fun decodeEditorBitmap(
    context: android.content.Context,
    uri: android.net.Uri,
    maxDimension: Int
): Bitmap? {
    val resolver = context.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

    var sample = 1
    while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) {
        sample *= 2
    }

    val options = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return resolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, options)
    }
}

@Composable
fun FinePhotoEditorApp() {
    val viewModel: MainViewModel = viewModel()
    val state by viewModel.uiState.collectAsState()
    var showBrandIntro by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(1550)
        showBrandIntro = false
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = fineDarkColorScheme.background
    ) {
        Box(Modifier.fillMaxSize()) {
            when (state.currentScreen) {
                Screen.Home -> HomeScreen(viewModel, state)
                Screen.Editor -> EditorScreen(viewModel, state)
            }

            if (showBrandIntro) {
                AnimatedBrandIntro()
            }
        }
    }
}

@Composable
private fun AnimatedBrandIntro() {
    var started by remember { mutableStateOf(false) }
    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (started) 1f else 0.72f,
        animationSpec = androidx.compose.animation.core.spring(
            dampingRatio = 0.72f,
            stiffness = 420f
        ),
        label = "logoScale"
    )
    val alpha by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (started) 1f else 0f,
        animationSpec = androidx.compose.animation.core.tween(420),
        label = "logoAlpha"
    )

    LaunchedEffect(Unit) {
        started = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF21134D),
                        Color(0xFF0B0B12),
                        Color(0xFF050509)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                this.alpha = alpha
                scaleX = scale
                scaleY = scale
            }
        ) {
            Box(
                modifier = Modifier
                    .size(126.dp)
                    .clip(RoundedCornerShape(34.dp))
                    .background(Color(0xFF090A0F))
                    .padding(9.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(com.finephoto.editor.R.drawable.fine_logo),
                    contentDescription = "Fine Photo Editor",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(Modifier.height(24.dp))
            Text(
                text = "Fine Photo Editor",
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(Modifier.height(7.dp))
            Text(
                text = "EDIT  •  ENHANCE  •  CREATE",
                fontSize = 10.sp,
                letterSpacing = 2.sp,
                color = Color(0xFFB7A8FF),
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

data class UIState(
    val currentScreen: Screen = Screen.Home,
    val selectedImage: Bitmap? = null,
    val processedImage: Bitmap? = null,
    val adjustmentState: ImageProcessor.AdjustmentState = ImageProcessor.AdjustmentState(),
    val isProcessing: Boolean = false,
    val selectedCategory: String = "Basic",
    val selectedPreset: String? = null,
    val history: List<ImageProcessor.AdjustmentState> = emptyList(),
    val historyIndex: Int = -1,
    val zoomScale: Float = 1f,
    val panOffset: Offset = Offset.Zero,
    val exportQuality: Int = 90,
    val showBeforeAfter: Boolean = false
)

enum class Screen { Home, Editor }

class MainViewModel : androidx.lifecycle.ViewModel() {
    private val _uiState = MutableStateFlow(UIState())
    val uiState: StateFlow<UIState> = _uiState.asStateFlow()

    private val imageProcessor = ImageProcessor()
    private var originalBitmap: Bitmap? = null
    private var previewBitmap: Bitmap? = null
    private var processingJob: Job? = null
    private var historyJob: Job? = null
    private var renderVersion = 0L

    fun loadImage(bitmap: Bitmap) {
        processingJob?.cancel()
        historyJob?.cancel()
        originalBitmap?.takeIf { it !== bitmap && !it.isRecycled }?.recycle()
        previewBitmap?.takeIf { !it.isRecycled }?.recycle()

        originalBitmap = bitmap
        previewBitmap = imageProcessor.createPreviewBitmap(bitmap, 1080)
        val clean = ImageProcessor.AdjustmentState()
        _uiState.value = UIState(
            currentScreen = Screen.Editor,
            selectedImage = previewBitmap,
            processedImage = previewBitmap,
            adjustmentState = clean,
            history = listOf(imageProcessor.snapshot(clean)),
            historyIndex = 0
        )
        processImage(immediate = true)
    }

    fun updateAdjustment(block: ImageProcessor.AdjustmentState.() -> Unit) {
        val current = _uiState.value.adjustmentState
        val next = imageProcessor.snapshot(current).apply(block)
        _uiState.update { it.copy(adjustmentState = next, selectedPreset = null) }

        // Don't create a history entry for every finger movement. Commit once the user pauses.
        historyJob?.cancel()
        historyJob = viewModelScope.launch {
            delay(350)
            val committed = imageProcessor.snapshot(_uiState.value.adjustmentState)
            _uiState.update { state ->
                val base = state.history.take(state.historyIndex + 1)
                val newHistory = if (base.lastOrNull() == committed) base else base + committed
                state.copy(history = newHistory, historyIndex = newHistory.lastIndex)
            }
        }
        processImage()
    }

    fun undo() {
        historyJob?.cancel()
        val history = _uiState.value.history
        val index = _uiState.value.historyIndex
        if (index > 0) {
            val next = imageProcessor.snapshot(history[index - 1])
            _uiState.update { it.copy(historyIndex = index - 1, adjustmentState = next, selectedPreset = null) }
            processImage(immediate = true)
        }
    }

    fun redo() {
        historyJob?.cancel()
        val history = _uiState.value.history
        val index = _uiState.value.historyIndex
        if (index < history.lastIndex) {
            val next = imageProcessor.snapshot(history[index + 1])
            _uiState.update { it.copy(historyIndex = index + 1, adjustmentState = next, selectedPreset = null) }
            processImage(immediate = true)
        }
    }

    fun reset() {
        historyJob?.cancel()
        val clean = ImageProcessor.AdjustmentState()
        _uiState.update {
            it.copy(
                adjustmentState = clean,
                history = listOf(imageProcessor.snapshot(clean)),
                historyIndex = 0,
                selectedPreset = null
            )
        }
        processImage(immediate = true)
    }

    suspend fun autoEnhance() {
        val bitmap = originalBitmap ?: return
        val autoState = imageProcessor.autoEnhance(bitmap)
        _uiState.update { it.copy(adjustmentState = autoState, selectedPreset = null) }
        processImage(immediate = true)
    }

    fun applyPreset(preset: Preset) {
        historyJob?.cancel()
        val newState = preset.applyTo(ImageProcessor.AdjustmentState())
        val snapshot = imageProcessor.snapshot(newState)
        _uiState.update {
            val base = it.history.take(it.historyIndex + 1)
            val h = base + snapshot
            it.copy(adjustmentState = snapshot, selectedPreset = preset.name, history = h, historyIndex = h.lastIndex)
        }
        processImage(immediate = true)
    }

    private fun processImage(immediate: Boolean = false) {
        processingJob?.cancel()
        val version = ++renderVersion
        processingJob = viewModelScope.launch(Dispatchers.Default) {
            if (!immediate) delay(55)
            val bitmap = previewBitmap ?: return@launch
            val state = imageProcessor.snapshot(_uiState.value.adjustmentState)
            _uiState.update { it.copy(isProcessing = true) }
            val processed = imageProcessor.processImage(bitmap, state, previewMode = true)
            if (version != renderVersion || !isActive) {
                if (!processed.isRecycled) processed.recycle()
                return@launch
            }
            _uiState.update { it.copy(processedImage = processed, isProcessing = false) }
        }
    }

    suspend fun renderFullResolution(): Bitmap? {
        val bitmap = originalBitmap ?: return null
        val state = imageProcessor.snapshot(_uiState.value.adjustmentState)
        return imageProcessor.processImage(bitmap, state, previewMode = false)
    }

    override fun onCleared() {
        processingJob?.cancel()
        historyJob?.cancel()
        previewBitmap?.takeIf { !it.isRecycled }?.recycle()
        originalBitmap?.takeIf { !it.isRecycled }?.recycle()
        super.onCleared()
    }

    fun goHome() {
        _uiState.update { it.copy(currentScreen = Screen.Home) }
    }

    fun updateZoomScale(scale: Float) {
        _uiState.update { it.copy(zoomScale = scale.coerceIn(0.5f, 3f)) }
    }

    fun updatePanOffset(offset: Offset) {
        _uiState.update { it.copy(panOffset = offset) }
    }

    fun toggleBeforeAfter() {
        _uiState.update { it.copy(showBeforeAfter = !it.showBeforeAfter) }
    }
}

data class Preset(
    val name: String,
    val category: String,
    val icon: String,
    val applyTo: (ImageProcessor.AdjustmentState) -> ImageProcessor.AdjustmentState
)

object Presets {
    private val names = listOf(
        "Cinematic", "Golden Hour", "Moody", "Dreamy", "Clean", "Urban", "Street", "Travel", "Portrait", "Film", "Vintage", "Retro",
        "Noir", "Pastel", "Vivid", "Matte", "Editorial", "Luxury", "Minimal", "Warm", "Cool", "Teal", "Orange", "Faded",
        "Sunset", "Ocean", "Forest", "Desert", "Neon", "Cyber", "Classic", "Natural", "Soft", "Bold", "Drama", "Night",
        "Dawn", "Dusk", "Coffee", "Autumn", "Winter", "Summer", "Spring", "Golden", "Silver", "Rose", "Lavender", "Emerald",
        "Sapphire", "Ruby", "Amber", "Arctic", "Tropical", "Coastal", "Mountain", "City", "Studio", "Wedding", "Fashion", "Food",
        "Cafe", "Architecture", "Luxury Film", "Analog", "35mm", "Polaroid", "Kodak", "Fuji", "Ilford", "Chrome", "Classic Film", "Cinema",
        "Indie", "Music", "Concert", "Sports", "Fitness", "Creator", "Social", "Reel", "TikTok", "Story", "Minimal Dark", "High Key",
        "Low Key", "Bright", "Airy", "Deep", "Rich", "Crisp", "Soft Matte", "Cream", "Peach", "Mint", "Sky", "Berry",
        "Chocolate", "Honey", "Copper", "Steel", "Platinum", "Midnight", "Moonlight", "Starlight", "Electric", "Aurora", "Haze", "Mist"
    )
    private val icons = listOf("✦", "◈", "✧", "◆", "●", "◉", "◇", "✺")
    val categories = listOf("Cinematic", "Portrait", "Travel", "Film", "Vintage", "Moody", "Social", "Creative")

    val all: List<Preset> = (0 until 120).map { i ->
        val base = names[i % names.size]
        val variant = i / names.size + 1
        val name = if (variant == 1) base else "$base $variant"
        val category = categories[i % categories.size]
        Preset(name, category, icons[i % icons.size]) { original ->
            val s = original.copy()
            val wave = i % 12
            s.exposure = ((wave - 5) / 12f).coerceIn(-0.45f, 0.45f)
            s.contrast = (((i * 7) % 15 - 7) / 15f).coerceIn(-0.5f, 0.5f)
            s.saturation = (((i * 11) % 17 - 8) / 17f).coerceIn(-0.5f, 0.5f)
            s.vibrance = (((i * 5) % 13 - 6) / 13f).coerceIn(-0.45f, 0.45f)
            s.temperature = (((i * 3) % 13 - 6) / 13f).coerceIn(-0.45f, 0.45f)
            s.tint = (((i * 9) % 11 - 5) / 11f).coerceIn(-0.4f, 0.4f)
            s.highlights = -((i % 7) / 18f)
            s.shadows = (i % 6) / 15f
            s.clarity = ((i % 9) / 18f)
            s.sharpen = ((i % 8) / 20f)
            s.grain = if (i % 4 == 0) (i % 7) / 18f else 0f
            s.vignette = if (i % 5 == 0) (i % 8) / 14f else 0f
            s.fade = if (i % 6 == 0) (i % 6) / 16f else 0f
            s
        }
    }
}

data class FilterPreset(
    val name: String,
    val category: String,
    val icon: String,
    val applyTo: (ImageProcessor.AdjustmentState) -> ImageProcessor.AdjustmentState
)

object Filters {
    private val styles = listOf(
        "Luma", "Chrome", "Velvet", "Silk", "Cobalt", "Amber", "Rose", "Mint", "Ice", "Fire", "Film",
        "Fade", "Glow", "Matte", "Punch", "Soft", "Deep", "Clean", "Dream", "Noir", "Retro", "Analog",
        "VHS", "Polaroid", "35mm", "Grain", "Dust", "Bloom", "Neon", "Cyber", "Cinema", "Drama", "Editorial",
        "Portrait", "Skin", "Golden", "Sunset", "Dusk", "Night", "Ocean", "Forest", "Desert", "Arctic", "Tropical",
        "Urban", "Street", "Cafe", "Luxury", "Fashion", "Classic", "Natural", "Vivid", "Pastel", "Cream", "Peach",
        "Berry", "Honey", "Copper", "Steel", "Silver", "Platinum", "Emerald", "Sapphire", "Ruby", "Lavender",
        "Sky", "Moon", "Star", "Aurora", "Haze", "Mist", "Cloud", "Rain", "Summer", "Winter", "Spring", "Autumn",
        "High Key", "Low Key", "Bright", "Dark", "Rich", "Crisp", "Soft Focus", "Hard Light", "Muted", "Faded", "Warm",
        "Cool", "Teal", "Orange", "Split Tone", "Monochrome", "Sepia", "Duotone", "Bleach", "Magazine", "Creator", "Social",
        "Reel", "Story", "Concert", "Sports", "Food", "Architecture", "Wedding", "Travel", "Pro", "Signature"
    )
    private val groups = listOf("Film", "Color", "Mood", "Portrait", "Travel", "Vintage", "Creative", "Social", "B&W", "Cinema")
    private val icons = listOf("◉", "◌", "✦", "◆", "◇", "✧", "●", "◈")

    val all: List<FilterPreset> = (0 until 120).map { i ->
        val base = styles[i % styles.size]
        val variant = i / styles.size + 1
        val name = if (variant == 1) base else "$base $variant"
        FilterPreset(name, groups[i % groups.size], icons[i % icons.size]) { original ->
            val s = original.copy()
            val k = i % 20
            s.saturation = ((k - 9) / 18f).coerceIn(-0.5f, 0.5f)
            s.contrast = (((k * 3) % 13 - 6) / 14f).coerceIn(-0.45f, 0.45f)
            s.temperature = (((k * 5) % 15 - 7) / 16f).coerceIn(-0.45f, 0.45f)
            s.vibrance = (((k * 7) % 13 - 6) / 16f).coerceIn(-0.4f, 0.4f)
            s.highlights = -((k % 6) / 16f)
            s.shadows = (k % 7) / 18f
            s.fade = if (i % 3 == 0) (k % 6) / 16f else 0f
            s.grain = if (i % 4 == 0) (k % 7) / 18f else 0f
            s.vignette = if (i % 5 == 0) (k % 6) / 14f else 0f
            s
        }
    }
}

data class QuickTool(
    val name: String,
    val icon: String,
    val applyTo: (ImageProcessor.AdjustmentState) -> ImageProcessor.AdjustmentState
)

object QuickTools {
    private val names = listOf(
        "Auto", "Exposure", "Contrast", "Highlights", "Shadows", "Whites", "Blacks", "Warmth", "Coolness", "Tint",
        "Saturation", "Vibrance", "Clarity", "Texture", "Dehaze", "Sharpen", "Grain", "Vignette", "Fade", "Punch",
        "Soft Light", "Deep Shadows", "Bright Whites", "Matte", "Film Wash", "Color Pop", "Skin Soft", "Sky Boost", "Detail",
        "Portrait Light", "Golden Light", "Blue Hour", "Sunset Glow", "Night Boost", "Street Pop", "Travel Pop", "Food Pop", "Green Boost", "Blue Boost",
        "Red Boost", "Orange Boost", "Yellow Boost", "Purple Boost", "Cyan Boost", "Vintage Wash", "Cinema Wash", "Noir", "Dream", "Glow",
        "Bloom", "Haze", "Fog", "Dust", "Analog", "Retro", "Polaroid", "VHS", "Chrome", "Sepia", "B&W", "High Key", "Low Key",
        "Clean Skin", "Soft Skin", "Face Light", "Eye Pop", "Hair Detail", "Background Fade", "Subject Pop", "Depth", "Micro Contrast", "Macro Detail",
        "Landscape", "Architecture", "Portrait Pro", "Studio Pro", "Wedding", "Fashion", "Creator", "Social", "Reel", "Story", "Thumbnail", "Profile",
        "Cafe", "Nightlife", "Concert", "Sports", "Beach", "Mountain", "Forest", "Desert", "City", "Neon City", "Luxury", "Minimal",
        "Warm Film", "Cool Film", "Faded Film", "Rich Film", "Cinematic", "Editorial", "Magazine", "Classic", "Modern", "Signature"
    )
    val all: List<QuickTool> = (0 until 120).map { i ->
        QuickTool(names[i % names.size] + if (i >= names.size) " ${i / names.size + 1}" else "", "✦") { original ->
            val s = original.copy()
            when (i % 12) {
                0 -> { s.exposure = 0.12f; s.contrast = 0.12f; s.vibrance = 0.16f }
                1 -> s.exposure = (s.exposure + 0.18f).coerceIn(-2f, 2f)
                2 -> s.contrast = (s.contrast + 0.16f).coerceIn(-1f, 1f)
                3 -> s.highlights = (s.highlights - 0.16f).coerceIn(-1f, 1f)
                4 -> s.shadows = (s.shadows + 0.18f).coerceIn(-1f, 1f)
                5 -> s.whites = (s.whites + 0.15f).coerceIn(-1f, 1f)
                6 -> s.blacks = (s.blacks - 0.15f).coerceIn(-1f, 1f)
                7 -> s.temperature = (s.temperature + 0.15f).coerceIn(-1f, 1f)
                8 -> s.temperature = (s.temperature - 0.15f).coerceIn(-1f, 1f)
                9 -> s.saturation = (s.saturation + 0.16f).coerceIn(-1f, 1f)
                10 -> s.vibrance = (s.vibrance + 0.18f).coerceIn(-1f, 1f)
                11 -> { s.clarity = (s.clarity + 0.14f).coerceIn(-1f, 1f); s.sharpen = (s.sharpen + 0.1f).coerceIn(0f, 1f) }
            }
            s
        }
    }
}


@Composable
fun HomeScreen(viewModel: MainViewModel, state: UIState) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        result.data?.data?.let { uri ->
            scope.launch {
                decodeEditorBitmap(context, uri, 4096)?.let(viewModel::loadImage)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF08090D))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("FINE", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                Text("PHOTO EDITOR", color = Color(0xFF9A9CA7), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
            }
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF171923)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFF9B7CFF))
            }
        }

        Spacer(Modifier.height(28.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(235.dp)
                .clickable {
                    galleryLauncher.launch(Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI))
                },
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF12141C))
        ) {
            Box(Modifier.fillMaxSize()) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .size(150.dp)
                        .background(Color(0xFF241B48), RoundedCornerShape(80.dp))
                )
                Column(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.size(68.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF7C5CFF)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.AddPhotoAlternate, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
                    Spacer(Modifier.height(16.dp))
                    Text("Create something great", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("Choose a photo to start editing", color = Color(0xFF9B9DA8), fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("QUICK START", color = Color(0xFF777A87), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(
                Triple("Presets", Icons.Default.AutoAwesome, "16+"),
                Triple("Adjust", Icons.Default.Tune, "Pro"),
                Triple("AI Edit", Icons.Default.Psychology, "AI")
            ).forEach { item ->
                Card(
                    Modifier.weight(1f).height(108.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF12141C))
                ) {
                    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Icon(item.second, null, tint = Color(0xFFB7A8FF), modifier = Modifier.size(22.dp))
                        Column {
                            Text(item.first, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(item.third, color = Color(0xFF686B78), fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("TOOLS", color = Color(0xFF777A87), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
            Text("Professional workflow", color = Color(0xFF565965), fontSize = 11.sp)
        }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF101219))) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                listOf(
                    Pair(Icons.Default.ColorLens, "Color & HSL"),
                    Pair(Icons.Default.AutoFixHigh, "AI Auto Enhance"),
                    Pair(Icons.Default.PhotoSizeSelectLarge, "Full Resolution Export")
                ).forEach { row ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(row.first, null, tint = Color(0xFF8D72FF), modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(14.dp))
                        Text(row.second, color = Color(0xFFD7D8DE), fontSize = 13.sp)
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF555865), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(viewModel: MainViewModel, state: UIState) {
    var selectedTool by remember { mutableStateOf("Presets") }
    var showSaveDialog by remember { mutableStateOf(false) }
    var exportQuality by remember { mutableStateOf(92) }
    var showOriginal by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val image = if (showOriginal) state.selectedImage else state.processedImage

    val tools = listOf(
        "Presets" to Icons.Default.AutoAwesome,
        "Filters" to Icons.Default.FilterVintage,
        "Adjust" to Icons.Default.Tune,
        "Color" to Icons.Default.ColorLens,
        "Effects" to Icons.Default.WbTwilight,
        "Tools" to Icons.Default.Crop,
        "AI" to Icons.Default.Psychology
    )

    Column(Modifier.fillMaxSize().background(Color(0xFF05060A))) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.goHome() }) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text("EDIT", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text(if (state.isProcessing) "Processing preview…" else "Fine Photo", color = Color(0xFF777A86), fontSize = 10.sp)
            }
            IconButton(onClick = { showOriginal = !showOriginal }) {
                Icon(Icons.Default.Compare, "Before after", tint = if (showOriginal) Color(0xFF9B7CFF) else Color.White)
            }
            IconButton(onClick = { viewModel.undo() }, enabled = state.historyIndex > 0) {
                Icon(Icons.Default.Undo, "Undo", tint = if (state.historyIndex > 0) Color.White else Color(0xFF444650))
            }
            IconButton(onClick = { showSaveDialog = true }) { Icon(Icons.Default.IosShare, "Export", tint = Color(0xFFB7A8FF)) }
        }

        Box(
            Modifier.fillMaxWidth().weight(1f).padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            if (image != null) {
                androidx.compose.foundation.Image(
                    bitmap = image.asImageBitmap(),
                    contentDescription = "Edited photo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Photo, null, tint = Color(0xFF454752), modifier = Modifier.size(54.dp))
                    Text("Choose a photo", color = Color(0xFF777A86), fontSize = 14.sp)
                }
            }
            if (state.isProcessing) {
                Surface(
                    Modifier.align(Alignment.TopCenter).padding(top = 12.dp),
                    shape = RoundedCornerShape(50), color = Color(0xCC11131A)
                ) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = Color(0xFF9B7CFF))
                        Spacer(Modifier.width(8.dp))
                        Text("Rendering", color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        }

        Surface(color = Color(0xFF0B0C11)) {
            Column(Modifier.fillMaxWidth()) {
                LazyRow(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(tools) { (name, icon) ->
                        val selected = selectedTool == name
                        Column(
                            Modifier.width(66.dp).clip(RoundedCornerShape(14.dp)).clickable { selectedTool = name }.padding(vertical = 7.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(icon, null, tint = if (selected) Color(0xFFB7A8FF) else Color(0xFF747783), modifier = Modifier.size(21.dp))
                            Spacer(Modifier.height(4.dp))
                            Text(name, color = if (selected) Color.White else Color(0xFF747783), fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                            Spacer(Modifier.height(3.dp))
                            Box(Modifier.width(18.dp).height(2.dp).clip(RoundedCornerShape(2.dp)).background(if (selected) Color(0xFF8B6DFF) else Color.Transparent))
                        }
                    }
                }

                Divider(color = Color(0xFF1B1D25))

                Column(
                    Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 310.dp).verticalScroll(rememberScrollState()).padding(14.dp)
                ) {
                    when (selectedTool) {
                        "Presets" -> {
                            val categories = Presets.categories
                            var category by remember { mutableStateOf(categories.firstOrNull() ?: "Basic") }
                            Text("LOOKS", color = Color(0xFF6E7180), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                            Spacer(Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                items(categories) { c ->
                                    FilterChip(
                                        selected = category == c,
                                        onClick = { category = c },
                                        label = { Text(c, fontSize = 11.sp) },
                                        modifier = Modifier.height(32.dp),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = Color(0xFF7C5CFF), selectedLabelColor = Color.White,
                                            containerColor = Color(0xFF171923), labelColor = Color(0xFF9B9DA8)
                                        )
                                    )
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(Presets.all.filter { it.category == category }) { preset ->
                                    Column(
                                        Modifier.width(72.dp).clickable { viewModel.applyPreset(preset) },
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Box(
                                            Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)).background(if (state.selectedPreset == preset.name) Color(0xFF7C5CFF) else Color(0xFF181A22)),
                                            contentAlignment = Alignment.Center
                                        ) { Text(preset.icon, fontSize = 25.sp) }
                                        Spacer(Modifier.height(5.dp))
                                        Text(preset.name, color = Color(0xFFBFC0C8), fontSize = 10.sp, maxLines = 1)
                                    }
                                }
                            }
                        }
                        "Filters" -> {
                            val groups = Filters.all.map { it.category }.distinct()
                            var group by remember { mutableStateOf(groups.firstOrNull() ?: "Film") }
                            Text("100+ FILTERS", color = Color(0xFF6E7180), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                            Spacer(Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                items(groups) { g ->
                                    FilterChip(selected = group == g, onClick = { group = g }, label = { Text(g, fontSize = 11.sp) }, modifier = Modifier.height(32.dp), colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF7C5CFF), selectedLabelColor = Color.White, containerColor = Color(0xFF171923), labelColor = Color(0xFF9B9DA8)))
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(Filters.all.filter { it.category == group }) { filter ->
                                    Column(Modifier.width(72.dp).clickable { viewModel.applyPreset(Preset(filter.name, filter.category, filter.icon, filter.applyTo)) }, horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF181A22)), contentAlignment = Alignment.Center) { Text(filter.icon, fontSize = 25.sp, color = Color(0xFFB7A8FF)) }
                                        Spacer(Modifier.height(5.dp))
                                        Text(filter.name, color = Color(0xFFBFC0C8), fontSize = 10.sp, maxLines = 1)
                                    }
                                }
                            }
                        }
                        "Adjust" -> {
                            Text("LIGHT", color = Color(0xFF6E7180), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                            AdjustmentSlider("Exposure", state.adjustmentState.exposure, -2f..2f) { viewModel.updateAdjustment { exposure = it } }
                            AdjustmentSlider("Contrast", state.adjustmentState.contrast, -1f..1f) { viewModel.updateAdjustment { contrast = it } }
                            AdjustmentSlider("Highlights", state.adjustmentState.highlights, -1f..1f) { viewModel.updateAdjustment { highlights = it } }
                            AdjustmentSlider("Shadows", state.adjustmentState.shadows, -1f..1f) { viewModel.updateAdjustment { shadows = it } }
                            AdjustmentSlider("Whites", state.adjustmentState.whites, -1f..1f) { viewModel.updateAdjustment { whites = it } }
                            AdjustmentSlider("Blacks", state.adjustmentState.blacks, -1f..1f) { viewModel.updateAdjustment { blacks = it } }
                        }
                        "Color" -> {
                            Text("COLOR", color = Color(0xFF6E7180), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                            AdjustmentSlider("Temperature", state.adjustmentState.temperature, -1f..1f) { viewModel.updateAdjustment { temperature = it } }
                            AdjustmentSlider("Tint", state.adjustmentState.tint, -1f..1f) { viewModel.updateAdjustment { tint = it } }
                            AdjustmentSlider("Saturation", state.adjustmentState.saturation, -1f..1f) { viewModel.updateAdjustment { saturation = it } }
                            AdjustmentSlider("Vibrance", state.adjustmentState.vibrance, -1f..1f) { viewModel.updateAdjustment { vibrance = it } }
                            Text("8-channel HSL mixer is available in the project engine.", color = Color(0xFF686B77), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                        }
                        "Effects" -> {
                            Text("FINISH", color = Color(0xFF6E7180), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                            AdjustmentSlider("Clarity", state.adjustmentState.clarity, -1f..1f) { viewModel.updateAdjustment { clarity = it } }
                            AdjustmentSlider("Sharpen", state.adjustmentState.sharpen, 0f..1f) { viewModel.updateAdjustment { sharpen = it } }
                            AdjustmentSlider("Grain", state.adjustmentState.grain, 0f..1f) { viewModel.updateAdjustment { grain = it } }
                            AdjustmentSlider("Vignette", state.adjustmentState.vignette, 0f..1f) { viewModel.updateAdjustment { vignette = it } }
                            AdjustmentSlider("Fade", state.adjustmentState.fade, 0f..1f) { viewModel.updateAdjustment { fade = it } }
                        }
                        "Tools" -> {
                            Text("100+ QUICK TOOLS", color = Color(0xFF6E7180), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                            Spacer(Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                items(QuickTools.all) { tool ->
                                    Column(Modifier.width(74.dp).clickable { viewModel.updateAdjustment { tool.applyTo(this) } }, horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(Modifier.size(58.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFF181A22)), contentAlignment = Alignment.Center) { Text(tool.icon, fontSize = 22.sp, color = Color(0xFFB7A8FF)) }
                                        Spacer(Modifier.height(4.dp)); Text(tool.name, color = Color(0xFFBFC0C8), fontSize = 9.sp, maxLines = 1)
                                    }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Text("TRANSFORM", color = Color(0xFF6E7180), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Rotate" to Icons.Default.RotateRight, "Flip H" to Icons.Default.Flip, "Flip V" to Icons.Default.Flip).forEach { (name, icon) ->
                                    OutlinedButton(onClick = { if (name == "Rotate") viewModel.updateAdjustment { rotation = (rotation + 90) % 360 } else if (name == "Flip H") viewModel.updateAdjustment { flipHorizontal = !flipHorizontal } else viewModel.updateAdjustment { flipVertical = !flipVertical } }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Icon(icon, null, Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text(name, fontSize = 11.sp) }
                                }
                            }
                            AdjustmentSlider("Straighten", state.adjustmentState.straighten, -45f..45f) { viewModel.updateAdjustment { straighten = it } }
                        }
                        "AI" -> {
                            Text("SMART EDIT", color = Color(0xFF6E7180), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                            Spacer(Modifier.height(8.dp))
                            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF171523)), modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF7C5CFF)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoFixHigh, null, tint = Color.White) }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) { Text("Auto Enhance", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text("Balance exposure, color and contrast", color = Color(0xFF858795), fontSize = 11.sp) }
                                    Button(onClick = { scope.launch { viewModel.autoEnhance() } }, shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF))) { Text("Apply", fontSize = 11.sp) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            containerColor = Color(0xFF15171F),
            title = { Text("Export", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("JPEG quality", color = Color(0xFF9B9DA8), fontSize = 12.sp)
                    Slider(value = exportQuality.toFloat(), onValueChange = { exportQuality = it.toInt() }, valueRange = 50f..100f)
                    Text("$exportQuality%", color = Color.White, fontSize = 12.sp, modifier = Modifier.align(Alignment.End))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showSaveDialog = false
                    scope.launch {
                        Toast.makeText(context, "Rendering full resolution…", Toast.LENGTH_SHORT).show()
                        viewModel.renderFullResolution()?.let { bitmap ->
                            saveImageToGallery(context, bitmap, exportQuality)
                            if (!bitmap.isRecycled) bitmap.recycle()
                            Toast.makeText(context, "Saved to Gallery", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Text("Export", color = Color(0xFFB7A8FF), fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showSaveDialog = false }) { Text("Cancel", color = Color(0xFF8B8D98)) } }
        )
    }
}

@Composable
fun AdjustmentSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = Color.White, fontSize = 13.sp)
            Text(String.format("%.1f", value), color = Color.Gray, fontSize = 12.sp)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF007AFF),
                activeTrackColor = Color(0xFF007AFF),
                inactiveTrackColor = Color(0xFF2A2A2A)
            ),
            modifier = Modifier.height(28.dp)
        )
    }
}

suspend fun saveImageToGallery(context: android.content.Context, bitmap: Bitmap, quality: Int) {
    withContext(Dispatchers.IO) {
        val filename = "FinePhoto_${System.currentTimeMillis()}.jpg"
        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FinePhotoEditor")
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
            }
        }
    }
}

