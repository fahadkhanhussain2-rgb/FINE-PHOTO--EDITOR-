package com.finephoto.editor.engine

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.UUID

/**
 * Optional cloud AI bridge. The key is supplied by the user at runtime and is never hard-coded.
 * For a production app, proxy these calls through your own backend instead of shipping a key in
 * a mobile client.
 */
class OpenAiImageClient {
    suspend fun editImage(apiKey: String, bitmap: Bitmap, prompt: String): Bitmap {
        val bytes = ByteArrayOutputStream().also {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 88, it)
        }.toByteArray()
        if (bytes.size > 12_000_000) error("Image is too large for AI editing. Try a smaller photo.")

        val boundary = "----FineAI-${UUID.randomUUID()}"
        val connection = open("https://api.openai.com/v1/images/edits", apiKey)
        connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        connection.doOutput = true

        connection.outputStream.use { out ->
            field(out, boundary, "model", "gpt-image-2")
            field(out, boundary, "prompt", buildEditPrompt(prompt))
            field(out, boundary, "quality", "high")
            field(out, boundary, "output_format", "jpeg")
            file(out, boundary, "image[]", "fine-input.jpg", "image/jpeg", bytes)
            out.write("--$boundary--\r\n".toByteArray())
        }
        return readImage(connection)
    }

    suspend fun generateImage(apiKey: String, prompt: String): Bitmap {
        val connection = open("https://api.openai.com/v1/images/generations", apiKey)
        connection.requestMethod = "POST"
        connection.setRequestProperty("Content-Type", "application/json")
        connection.doOutput = true
        val body = JSONObject()
            .put("model", "gpt-image-2")
            .put("prompt", prompt)
            .put("size", "1024x1024")
            .put("quality", "high")
            .put("output_format", "jpeg")
            .toString()
        connection.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
        return readImage(connection)
    }

    private fun buildEditPrompt(userPrompt: String): String = """
        Edit the supplied photo according to the user's instruction.
        You are a professional commercial photo editor and visual director.
        Interpret the request intelligently instead of applying a generic preset.
        Preserve the person's identity, facial structure, natural anatomy and important objects unless the user explicitly asks to change them.
        Make lighting, skin, color, contrast, depth, atmosphere, composition and fine detail coherent and photorealistic.
        If the user asks for Hollywood, cinematic, portrait, luxury, fashion, night, film or a named visual style, build the complete look rather than merely changing saturation.
        If the user asks to add, remove, replace or transform an object/background, perform that edit naturally and blend edges, shadows and lighting.
        User instruction: $userPrompt
    """.trimIndent()

    private fun open(url: String, apiKey: String): HttpURLConnection {
        return (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 180_000
            useCaches = false
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Accept", "application/json")
        }
    }

    private fun field(out: java.io.OutputStream, boundary: String, name: String, value: String) {
        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
        out.write(value.toByteArray(StandardCharsets.UTF_8))
        out.write("\r\n".toByteArray())
    }

    private fun file(out: java.io.OutputStream, boundary: String, name: String, filename: String, mime: String, bytes: ByteArray) {
        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"$name\"; filename=\"$filename\"\r\n".toByteArray())
        out.write("Content-Type: $mime\r\n\r\n".toByteArray())
        out.write(bytes)
        out.write("\r\n".toByteArray())
    }

    private fun readImage(connection: HttpURLConnection): Bitmap {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val message = runCatching { JSONObject(text).optJSONObject("error")?.optString("message") }.getOrNull()
            error(message?.takeIf { it.isNotBlank() } ?: "AI request failed ($code)")
        }
        val json = JSONObject(text)
        val data = json.optJSONArray("data") ?: error("AI returned no image")
        val first = data.optJSONObject(0) ?: error("AI returned no image")
        val b64 = first.optString("b64_json").takeIf { it.isNotBlank() } ?: error("AI returned no image data")
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        return android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: error("AI image could not be decoded")
    }
}
