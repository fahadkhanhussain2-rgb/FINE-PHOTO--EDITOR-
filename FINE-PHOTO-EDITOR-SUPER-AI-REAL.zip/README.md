# FINE PHOTO EDITOR - Professional Photo Editor

## Features
- Import from Gallery & Camera
- Full image editing (Exposure, Contrast, Highlights, Shadows, etc.)
- 8-Channel HSL adjustments
- 16 Professional Presets
- AI Auto-Enhance
- Undo/Redo/Reset
- Pinch-to-zoom & Pan
- Before/After comparison
- Export to Gallery

## GitHub Actions build
The included workflow installs Gradle 8.2 and Android SDK 34, then builds the debug APK automatically.

Artifact: `FinePhotoEditor-Debug`


## AI-first experience
- AI Auto Enhance with local analysis
- AI Portrait, Cinematic, Night Fix, Sky Pop, Golden Hour, Clean Pro and Film Look modes
- AI-first studio navigation and premium dark visual system
- Preview-first processing with full-resolution export
- 120+ looks, 120+ filters and 120+ quick tools

The app is designed as an AI-assisted, local-first editor: the default AI actions aim for natural-looking improvements rather than destructive or obviously artificial edits.
